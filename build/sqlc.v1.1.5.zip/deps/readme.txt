依赖说明：
优先使用包管理器安装依赖，例如：yum search readline
如果包管理器不可用或没有找到，则依次安装此文件夹重的两个依赖readline和rlwrap！
